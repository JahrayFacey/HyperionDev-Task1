# Use input to ask user for their name, age, house number and street name.
# print out a statement containing all of the user's typed details.
name = input("What is your name? ")
age = int(input("How old are you? "))
House = int(input("What is your house number? "))
street = input("What is your street name? ")
print(f"This is {name}. He is {age} years old and lives at house number {House} on {street}.")