# covert the values 99.23, 23, 150 and '100' into an integer, float, String, interger respectively
# Print out the new, converted variables
num1 = 99.23
num2 = 23
num3 = 150
string1 = "100"
new_num1 = int(num1)
new_num2 =  float(num2)
new_num3 = str(num3)
new_string1 = int(string1)
print(new_num1)
print(new_num2)
print(new_num3)
print(new_string1)