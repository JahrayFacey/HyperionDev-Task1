# Prompt the user for their name and age.
# print "Hello World!" on a new line
name = input("What is your name? ")
print(name)
age = int(input("How old are you? "))
print(age)
print("Hello World!")